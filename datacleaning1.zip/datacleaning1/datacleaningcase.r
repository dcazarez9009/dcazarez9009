# Load necessary libraries
library(dplyr)
library(readr)
library(stringr)

# Specify the file path (updated to 'datacleaning1')
file_path <- "/Users/danielcazarez/Desktop/datacleaning1/email_list.csv"

# Load the CSV file
email_data <- read_csv(file_path)

# Define regex pattern for valid emails (excludes phone-like patterns)
email_pattern <- "^(?!\\+?[0-9-]{7,})[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"

# Add a column to indicate validity (case-insensitive)
email_data <- email_data |>
  mutate(valid = str_detect(email, regex(email_pattern, ignore_case = TRUE)))

# Separate valid and invalid emails
valid_emails <- email_data |>
  filter(valid) |>
  select(email)

invalid_emails <- email_data |>
  filter(!valid) |>
  select(email)

# Save cleaned data to new CSV files (updated path)
write_csv(valid_emails, "/Users/danielcazarez/Desktop/datacleaning1/valid_emails.csv")
write_csv(invalid_emails, "/Users/danielcazarez/Desktop/datacleaning1/invalid_emails.csv")

# Print summary
cat(
  "Cleaning complete:\n",
  "Valid emails:", nrow(valid_emails), "\n",
  "Invalid emails:", nrow(invalid_emails), "\n",
  "Output saved to '/Users/danielcazarez/Desktop/datacleaning1/'\n"
)